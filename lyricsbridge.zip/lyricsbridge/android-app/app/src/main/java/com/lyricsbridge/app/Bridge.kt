package com.lyricsbridge.app

import android.content.ComponentName
import android.content.Context
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetAddress
import java.net.ServerSocket
import java.util.concurrent.Executors
import kotlin.concurrent.thread

/**
 * Servidor HTTP mínimo solo en 127.0.0.1. El mod de Minecraft (dentro de Zalith, en el mismo celular)
 * consulta GET /now cada ~250 ms y recibe la línea de letra actual.
 */
class Bridge(ctx: Context, component: ComponentName, private val port: Int = DEFAULT_PORT) {
    private val tracker = MediaTracker(ctx, component)
    private val pool = Executors.newSingleThreadExecutor()

    @Volatile private var key = ""
    @Volatile private var lines: List<LrcLine> = emptyList()
    @Volatile private var loaded = false
    @Volatile private var server: ServerSocket? = null

    fun start() {
        thread(isDaemon = true, name = "lyricsbridge-http") {
            val ss = try {
                ServerSocket(port, 8, InetAddress.getByName("127.0.0.1"))
            } catch (e: Exception) {
                return@thread
            }
            server = ss
            while (!ss.isClosed) {
                try {
                    ss.accept().use { s ->
                        s.soTimeout = 2000
                        val first = BufferedReader(InputStreamReader(s.getInputStream())).readLine() ?: return@use
                        val target = first.split(" ").getOrElse(1) { "/now" }
                        val offset = Regex("offset=(-?\\d+)").find(target)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
                        val body = nowJson(offset).toByteArray(Charsets.UTF_8)
                        val head = "HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\n" +
                            "Content-Length: ${body.size}\r\nConnection: close\r\n\r\n"
                        s.getOutputStream().apply { write(head.toByteArray()); write(body); flush() }
                    }
                } catch (e: Exception) {
                    if (ss.isClosed) break
                }
            }
        }
    }

    fun stop() {
        try { server?.close() } catch (_: Exception) {}
        pool.shutdownNow()
    }

    private fun isYoutube(pkg: String) = pkg.startsWith("com.google.android.youtube")

    private fun cleanTitle(t: String) = t.replace(
        Regex("""\s*[(\[][^)\]]*(official|video|audio|lyrics?|visualizer|hd|4k|mv|letra)[^)\]]*[)\]]""", RegexOption.IGNORE_CASE), ""
    ).trim()

    private fun nowJson(offsetMs: Long): String {
        val o = JSONObject()
        val s = tracker.snapshot() ?: return o.put("active", false).toString()

        var artist = s.artist.removeSuffix(" - Topic").trim()
        var title = s.title
        if (isYoutube(s.pkg)) {
            title = cleanTitle(title)
            if (title.contains(" - ")) {
                val parts = title.split(" - ", limit = 2)
                artist = parts[0].trim()
                title = parts[1].trim()
            }
        }

        val k = "${s.pkg}|$artist|$title|${s.durationMs}"
        if (k != key) {
            key = k
            lines = emptyList()
            loaded = false
            pool.execute {
                val r = try { Lrclib.find(title, artist, s.album, s.durationMs) } catch (e: Exception) { emptyList() }
                if (key == k) { lines = r; loaded = true }
            }
        }

        val ls = lines
        val p = s.positionMs + offsetMs
        var idx = -1
        var lo = 0
        var hi = ls.size - 1
        while (lo <= hi) {
            val mid = (lo + hi) / 2
            if (ls[mid].timeMs <= p) { idx = mid; lo = mid + 1 } else hi = mid - 1
        }
        fun text(i: Int) = ls.getOrNull(i)?.text?.ifBlank { "♪" } ?: ""

        return o.put("active", true)
            .put("playing", s.playing)
            .put("app", s.pkg)
            .put("title", title)
            .put("artist", artist)
            .put("positionMs", s.positionMs)
            .put("durationMs", s.durationMs)
            .put("loaded", loaded)
            .put("hasSynced", ls.isNotEmpty())
            .put("prev", if (idx > 0) text(idx - 1) else "")
            .put("line", if (idx >= 0) text(idx) else "")
            .put("next", text(idx + 1))
            .toString()
    }

    companion object { const val DEFAULT_PORT = 8765 }
}
