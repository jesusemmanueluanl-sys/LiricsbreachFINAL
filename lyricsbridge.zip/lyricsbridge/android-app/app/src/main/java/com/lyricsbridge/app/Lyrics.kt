package com.lyricsbridge.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class LrcLine(val timeMs: Long, val text: String)

object Lrc {
    private val TAG = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]""")

    fun parse(src: String): List<LrcLine> {
        val out = ArrayList<LrcLine>()
        for (raw in src.lineSequence()) {
            val tags = TAG.findAll(raw).toList()
            if (tags.isEmpty()) continue
            val text = raw.substring(tags.last().range.last + 1).trim()
            for (m in tags) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3].padEnd(3, '0').take(3).toLong()
                out += LrcLine(min * 60_000 + sec * 1_000 + frac, text)
            }
        }
        return out.sortedBy { it.timeMs }
    }
}

/** Cliente mínimo de https://lrclib.net (API pública y gratuita de letras sincronizadas). */
object Lrclib {
    private const val BASE = "https://lrclib.net/api"

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun JSONObject.str(k: String) = if (isNull(k)) "" else optString(k, "")

    private fun get(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        return try {
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "LyricsBridge/1.0 (personal Android companion)")
            if (c.responseCode == 200) c.inputStream.bufferedReader().readText() else null
        } catch (e: Exception) {
            null
        } finally {
            c.disconnect()
        }
    }

    fun find(title: String, artist: String, album: String, durationMs: Long): List<LrcLine> {
        val dur = if (durationMs > 0) "&duration=${durationMs / 1000}" else ""
        get("$BASE/get?track_name=${enc(title)}&artist_name=${enc(artist)}&album_name=${enc(album)}$dur")?.let {
            val synced = try { JSONObject(it).str("syncedLyrics") } catch (e: Exception) { "" }
            if (synced.isNotBlank()) return Lrc.parse(synced)
        }
        val body = get("$BASE/search?q=${enc("$artist $title".trim())}") ?: return emptyList()
        val arr = try { JSONArray(body) } catch (e: Exception) { return emptyList() }
        var best: JSONObject? = null
        var bestDiff = Long.MAX_VALUE
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.str("syncedLyrics").isBlank()) continue
            val diff = if (durationMs > 0) Math.abs((o.optDouble("duration", 0.0) * 1000).toLong() - durationMs) else 0L
            if (diff < bestDiff) { best = o; bestDiff = diff }
        }
        if (best == null || (durationMs > 0 && bestDiff > 8000)) return emptyList()
        return Lrc.parse(best.str("syncedLyrics"))
    }
}
