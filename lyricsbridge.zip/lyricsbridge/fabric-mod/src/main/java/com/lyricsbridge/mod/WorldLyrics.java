package com.lyricsbridge.mod;

import com.mojang.blaze3d.vertex.PoseStack;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Letra flotando en tu campo de vision, UNA palabra a la vez.
 * Todo se configura en config/lyricsbridge.properties (ver LyricsConfig).
 */
public final class WorldLyrics {
    private WorldLyrics() {}

    private static final int FULL_BRIGHT = 0xF000F0;
    private static final int MAX_ALIVE = 28;

    private static final class Floater {
        String text;
        double x, y, z;        // posicion en el mundo
        double vx, vy, vz;     // deriva lenta (bloques/segundo)
        float size;
        int rgb;
        long bornNs;
        double phase;
    }

    private static final List<Floater> alive = new ArrayList<>();
    private static final Random RNG = new Random();

    private static String curLine = "";
    private static String[] words = new String[0];
    private static long[] dueNs = new long[0];
    private static int spawned = 0;
    private static long lastNs = 0;
    private static int wordCounter = 0;

    public static void reset() {
        alive.clear();
        curLine = "";
        words = new String[0];
        dueNs = new long[0];
        spawned = 0;
        lastNs = 0;
    }

    /** true si en ese punto hay un bloque con colision (pared, suelo, techo...). */
    private static boolean solid(Level level, double x, double y, double z) {
        if (level == null) return false;
        BlockPos p = BlockPos.containing(x, y, z);
        BlockState st = level.getBlockState(p);
        return !st.getCollisionShape(level, p).isEmpty();
    }

    /** Distancia libre desde la camara en una direccion antes de topar con un bloque. */
    private static double freeDistance(Level level, Vec3 from, double dx, double dy, double dz, double max) {
        double d = 0.4;
        while (d <= max) {
            if (solid(level, from.x + dx * d, from.y + dy * d, from.z + dz * d)) {
                return d - 0.4;
            }
            d += 0.25;
        }
        return max;
    }

    /** Se llama cada frame desde LyricsBridgeClient. prev/next ya no se usan. */
    public static void render(LevelRenderContext ctx, String prev, String line, String next) {
        LyricsConfig c = LyricsConfig.get();
        long now = System.nanoTime();
        String l = line == null ? "" : line.trim();

        if (!l.equals(curLine)) {
            curLine = l;
            if (l.isEmpty()) {
                words = new String[0];
                dueNs = new long[0];
            } else {
                words = l.split("\\s+");
                dueNs = new long[words.length];
                long t = now;
                for (int i = 0; i < words.length; i++) {
                    dueNs[i] = t;
                    double ms = c.wordMs + 40.0 * words[i].length();
                    t += (long) (Math.min(ms, 1200.0) * 1_000_000.0);
                }
            }
            spawned = 0;
        }

        Minecraft mc = Minecraft.getInstance();
        Font font = mc.font;
        if (font == null) return;
        Level level = mc.level;

        CameraRenderState cam = ctx.levelState().cameraRenderState;
        Vec3 cp = cam.pos;

        // Soltar las palabras que ya les toca
        while (spawned < words.length && dueNs[spawned] <= now) {
            spawn(words[spawned], now, cam, level, c);
            spawned++;
        }

        double dt = lastNs == 0 ? 0.0 : Math.min(0.1, (now - lastNs) / 1_000_000_000.0);
        lastNs = now;

        if (alive.isEmpty()) return;

        long lifeNs = (long) (c.time * 1_000_000_000.0);
        Matrix4f billboard = new Matrix4f().rotation(cam.orientation);

        for (int i = alive.size() - 1; i >= 0; i--) {
            Floater f = alive.get(i);
            long age = now - f.bornNs;
            if (age >= lifeNs) {
                alive.remove(i);
                continue;
            }
            double s = age / 1_000_000_000.0;
            double t = age / (double) lifeNs; // 0..1

            // Mover: si el siguiente paso entra en un bloque, se queda quieta
            double nx = f.x + f.vx * dt;
            double ny = f.y + f.vy * dt;
            double nz = f.z + f.vz * dt;
            if (solid(level, nx, ny, nz)) {
                f.vx = 0;
                f.vy = 0;
                f.vz = 0;
            } else {
                f.x = nx;
                f.y = ny;
                f.z = nz;
            }

            // Opacidad: entra rapido, sale suave
            double a;
            if (s < 0.15) a = s / 0.15;
            else if (t > 0.7) a = (1.0 - t) / 0.3;
            else a = 1.0;
            int alpha = (int) Math.max(6, Math.min(255, a * 255));

            // La palabra mas reciente puede ir resaltada; las demas usan su color
            boolean newest = (i == alive.size() - 1);
            int rgb = (newest && c.newest >= 0) ? c.newest : f.rgb;
            int argb = (alpha << 24) | rgb;

            // Pop de tamano al aparecer
            double pop = s < 0.2 ? 0.6 + 2.0 * s : 1.0;
            float sc = (float) (c.scale * f.size * pop);

            // Balanceo suave solo si no esta pegada a un bloque
            double bob = f.vy == 0 ? 0 : Math.sin(s * 1.6 + f.phase) * 0.08;

            PoseStack pose = new PoseStack();
            pose.translate(f.x - cp.x, f.y + bob - cp.y, f.z - cp.z);
            pose.mulPose(billboard);
            pose.scale(sc, -sc, sc);

            FormattedCharSequence seq = Component.literal(f.text).getVisualOrderText();
            float w = font.width(seq);
            ctx.submitNodeCollector().submitText(
                    pose, -w / 2f, 0f, seq, c.shadow,
                    Font.DisplayMode.NORMAL, FULL_BRIGHT, argb, 0, 0);
        }
    }

    private static void spawn(String word, long now, CameraRenderState cam, Level level, LyricsConfig c) {
        Vec3 cp = cam.pos;

        // Direccion hacia donde mira la camara
        Vector3f fwd = cam.orientation.transform(new Vector3f(0f, 0f, -1f));
        double baseYaw = Math.atan2(fwd.z, fwd.x);
        double basePitch = Math.asin(Math.max(-1.0, Math.min(1.0, fwd.y)));

        // Probar varias direcciones dentro del campo de vision y quedarse con
        // la primera que tenga espacio libre; si ninguna, la que tenga mas.
        double bestR = -1, bx = 0, by = 0, bz = 0;
        for (int attempt = 0; attempt < 8; attempt++) {
            double yaw = baseYaw + Math.toRadians((RNG.nextDouble() * 2 - 1) * c.spreadYaw);
            double pitch = basePitch + Math.toRadians((RNG.nextDouble() * 2 - 1) * c.spreadPitch);
            pitch = Math.max(Math.toRadians(-75), Math.min(Math.toRadians(75), pitch));

            double dx = Math.cos(pitch) * Math.cos(yaw);
            double dy = Math.sin(pitch);
            double dz = Math.cos(pitch) * Math.sin(yaw);

            double want = c.distance + RNG.nextDouble() * c.range;
            double free = freeDistance(level, cp, dx, dy, dz, want);
            double r = Math.min(want, free - 0.3); // pegarse un poco antes del bloque

            if (r > bestR) {
                bestR = r;
                bx = dx;
                by = dy;
                bz = dz;
            }
            if (r >= want - 0.01 && r >= c.distance * 0.7) break; // espacio de sobra
        }

        // Todo bloqueado de frente: no mostrar la palabra (evita que salga dentro de una pared)
        if (bestR < 1.0) return;

        Floater f = new Floater();
        f.text = word;
        f.x = cp.x + bx * bestR;
        f.y = cp.y + by * bestR;
        f.z = cp.z + bz * bestR;
        f.vx = (RNG.nextDouble() - 0.5) * 0.3;
        f.vy = 0.15 + RNG.nextDouble() * 0.2;
        f.vz = (RNG.nextDouble() - 0.5) * 0.3;
        f.size = (float) (0.85 + RNG.nextDouble() * 0.6);
        f.phase = RNG.nextDouble() * Math.PI * 2.0;
        f.bornNs = now;

        // Color de esta palabra
        if (c.rainbow) {
            f.rgb = LyricsConfig.hue(wordCounter * 0.13);
        } else if (c.random) {
            f.rgb = c.colors[RNG.nextInt(c.colors.length)];
        } else {
            f.rgb = c.colors[wordCounter % c.colors.length];
        }
        wordCounter++;

        alive.add(f);
        while (alive.size() > MAX_ALIVE) alive.remove(0);
    }
}
