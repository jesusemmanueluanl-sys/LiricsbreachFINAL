package com.lyricsbridge.mod;

import net.fabricmc.loader.api.FabricLoader;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Configuracion de las letras. Archivo: <carpeta del juego>/config/lyricsbridge.properties
 * Se crea solo la primera vez y se recarga automaticamente al guardarlo (sin reiniciar).
 */
final class LyricsConfig {
    final double distance;     // distancia minima en bloques
    final double range;        // variacion extra de distancia
    final double time;         // segundos que vive cada palabra
    final double wordMs;       // ms base por palabra
    final double scale;        // tamano
    final double spreadYaw;    // grados a cada lado
    final double spreadPitch;  // grados arriba/abajo
    final boolean shadow;
    final boolean random;      // colores al azar en vez de en orden
    final boolean rainbow;     // arcoiris
    final int[] colors;        // paleta (RGB)
    final int newest;          // color de la palabra mas reciente (-1 = sin resaltar)

    private LyricsConfig(Map<String, String> m) {
        String style = m.getOrDefault("style", "default").trim().toLowerCase();

        // Valores del estilo (preset)
        int[] pal;
        int nw = 0xFFD54A;
        boolean rb = false;
        switch (style) {
            case "neon":
                pal = new int[]{0xFF4DFF, 0x4DFFFF, 0x7DFF4D, 0xFFF04D};
                nw = 0xFFFFFF;
                break;
            case "sunset":
                pal = new int[]{0xFF6B6B, 0xFFA94D, 0xFFD93D, 0xFF8FA3};
                nw = 0xFFFFFF;
                break;
            case "ocean":
                pal = new int[]{0x4DD0E1, 0x4D9BFF, 0x9BF6FF, 0xE0F7FA};
                nw = 0xFFFFFF;
                break;
            case "rainbow":
                pal = new int[]{0xFFFFFF};
                nw = -1;
                rb = true;
                break;
            case "white":
                pal = new int[]{0xFFFFFF};
                nw = -1;
                break;
            default: // "default": blanco con la ultima palabra en dorado
                pal = new int[]{0xFFFFFF};
                break;
        }

        // Valores personalizados (si se ponen, mandan sobre el estilo)
        List<Integer> custom = new ArrayList<>();
        String cs = m.get("colors");
        if (cs != null) {
            for (String part : cs.split("[,;\\s]+")) {
                Integer c = parseColor(part);
                if (c != null) custom.add(c);
            }
        }
        if (!custom.isEmpty()) {
            pal = new int[custom.size()];
            for (int i = 0; i < pal.length; i++) pal[i] = custom.get(i);
            rb = false;
        }

        String ns = m.get("newest");
        if (ns != null) {
            String t = ns.trim().toLowerCase();
            if (t.equals("none") || t.equals("off") || t.isEmpty()) nw = -1;
            else {
                Integer c = parseColor(t);
                if (c != null) nw = c;
            }
        }

        this.colors = pal;
        this.newest = nw;
        this.rainbow = rb;
        this.random = bool(m.get("random"), false);
        this.distance = clamp(num(m.get("distance"), 3.0), 1.0, 12.0);
        this.range = clamp(num(m.get("range"), 3.0), 0.0, 12.0);
        this.time = clamp(num(m.get("time"), 3.0), 0.5, 20.0);
        this.wordMs = clamp(num(m.get("wordms"), 380), 80, 3000);
        this.scale = clamp(num(m.get("scale"), 0.05), 0.01, 0.3);
        this.spreadYaw = clamp(num(m.get("spreadyaw"), 38), 5, 90);
        this.spreadPitch = clamp(num(m.get("spreadpitch"), 22), 5, 70);
        this.shadow = bool(m.get("shadow"), true);
    }

    // ---------- Estado global ----------
    private static volatile LyricsConfig cur = new LyricsConfig(new HashMap<>());
    private static long lastCheckMs = 0;
    private static long lastModified = -1;
    private static boolean created = false;

    static LyricsConfig get() {
        long now = System.currentTimeMillis();
        if (now - lastCheckMs > 1500) {
            lastCheckMs = now;
            poll();
        }
        return cur;
    }

    private static void poll() {
        try {
            Path file = FabricLoader.getInstance().getConfigDir().resolve("lyricsbridge.properties");
            if (!Files.exists(file)) {
                if (!created) {
                    created = true;
                    Files.writeString(file, DEFAULT_FILE, StandardCharsets.UTF_8);
                }
            }
            if (!Files.exists(file)) return;
            long mod = Files.getLastModifiedTime(file).toMillis();
            if (mod == lastModified) return;
            lastModified = mod;

            Map<String, String> m = new HashMap<>();
            for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
                String s = line.trim();
                if (s.isEmpty() || s.startsWith("#")) continue;
                int eq = s.indexOf('=');
                if (eq <= 0) continue;
                m.put(s.substring(0, eq).trim().toLowerCase(), s.substring(eq + 1).trim());
            }
            cur = new LyricsConfig(m);
        } catch (Exception ignored) {
            // si el archivo esta mal, se queda con la ultima config buena
        }
    }

    // ---------- Utilidades ----------
    private static double num(String s, double def) {
        if (s == null) return def;
        try {
            return Double.parseDouble(s.trim().replace(',', '.'));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private static boolean bool(String s, boolean def) {
        if (s == null) return def;
        String t = s.trim().toLowerCase();
        if (t.equals("true") || t.equals("si") || t.equals("1") || t.equals("on")) return true;
        if (t.equals("false") || t.equals("no") || t.equals("0") || t.equals("off")) return false;
        return def;
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static Integer parseColor(String s) {
        if (s == null) return null;
        String t = s.trim();
        if (t.startsWith("#")) t = t.substring(1);
        if (t.startsWith("0x") || t.startsWith("0X")) t = t.substring(2);
        if (t.length() != 6) return null;
        try {
            return Integer.parseInt(t, 16) & 0xFFFFFF;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** Color arcoiris (matiz 0..1) sin usar java.awt. */
    static int hue(double h) {
        h = h - Math.floor(h);
        double x = h * 6.0;
        int i = (int) x;
        double f = x - i;
        double q = 1.0 - f;
        double r, g, b;
        switch (i % 6) {
            case 0: r = 1; g = f; b = 0; break;
            case 1: r = q; g = 1; b = 0; break;
            case 2: r = 0; g = 1; b = f; break;
            case 3: r = 0; g = q; b = 1; break;
            case 4: r = f; g = 0; b = 1; break;
            default: r = 1; g = 0; b = q; break;
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    private static final String DEFAULT_FILE = String.join("\n",
            "# ===== LyricsBridge - configuracion =====",
            "# Guarda el archivo y los cambios se aplican solos (sin reiniciar el juego).",
            "",
            "# Distancia minima de las letras en bloques (1 a 12)",
            "distance=3.0",
            "# Variacion extra de distancia: cada palabra aparece entre distance y distance+range",
            "range=3.0",
            "",
            "# Segundos que dura cada palabra en pantalla (0.5 a 20)",
            "time=3.0",
            "# Velocidad: milisegundos base por palabra (menos = mas rapido)",
            "wordms=380",
            "",
            "# Tamano del texto (0.01 a 0.3)",
            "scale=0.05",
            "# Que tan abiertas aparecen: grados a los lados y arriba/abajo de tu vista",
            "spreadyaw=38",
            "spreadpitch=22",
            "# Sombra del texto: true o false",
            "shadow=true",
            "",
            "# --- COLORES ---",
            "# Estilo: default, white, neon, sunset, ocean, rainbow",
            "style=default",
            "# Tus propios colores (hex, separados por coma). Si los pones, mandan sobre el estilo.",
            "# Ejemplo:  colors=#FF4D4D,#4DFF88,#4D9BFF",
            "# colors=",
            "# Color de la palabra mas reciente (hex) o none para no resaltar.",
            "# newest=#FFD54A",
            "# Colores al azar en vez de en orden: true o false",
            "random=false",
            "");
}
