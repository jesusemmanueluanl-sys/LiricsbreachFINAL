# Avisos de terceros

- **Código propio:** MIT (ver LICENSE). Escrito desde cero; no contiene código del mod "Show the lyrics" (FireStund, All Rights Reserved) ni de ningún otro mod.
- **LRCLIB (https://lrclib.net):** servicio público y gratuito de letras sincronizadas, consultado en tiempo de ejecución. Las letras pertenecen a sus autores; este proyecto no las incluye, no las guarda en disco y no las redistribuye. Respeta los términos de LRCLIB.
- **Fabric Loader / Fabric API / Fabric Loom:** Apache-2.0 / MIT (https://fabricmc.net). Se descargan al compilar; no se incluyen en este repositorio.
- **Minecraft:** marca de Mojang AB / Microsoft. Proyecto no oficial, no afiliado ni aprobado por Mojang o Microsoft. No se incluye código ni recursos de Minecraft.
- **Spotify, YouTube, YouTube Music:** marcas de sus dueños. La app solo lee los metadatos que Android ya expone en la sesión multimedia; no accede a sus servidores ni a su audio.
- **App Android:** sin librerías de terceros (solo APIs del SDK de Android y Kotlin).
